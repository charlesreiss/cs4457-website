import argparse
import copy
import importlib
import random
import struct

from difflib import SequenceMatcher
from math import ceil

random_seed = 0

class Channel:
    """Implementation of class for Sender to call send_bytes on; holds received bytes in an array for tests to retrieve."""
    def __init__(self):
        self.got_bytes = bytearray()

    def send_bytes(self, the_bytes):
        if type(the_bytes) != bytes:
            raise ValueError("send_bytes() must be passed a value of type bytes")
        self.got_bytes += the_bytes

def _range(i, j):
    """Output 'message I through J' for error messages."""
    if i + 1 == j:
        return f'message #{i}'
    else:
        return f'messages #{i} through #{j-1} (inclusive)'

def _format_message(m):
    """Format message as sequence of hex bytes for error messages."""
    return m.hex(' ')


def run_one(sender_cls, receiver_cls, distort_function, sent_messages):
    """Run a test case:

    *  `sender_cls`: class implementing sender; should have __init__ method taking a channel argument.
       We will call its send_message() with a message (in bytes) to send, it should call the channel's
       send_bytes() method.
    *  `receiver_cls`: class implementing receiver; should have __init__ method taking a got_message_function
       argument. We will call the receiver's handle_byte_from_network function, it should call
       got_message_function with a bytes object.
    *  `distort_function`: function to call to corrupt what Sender sends
    *  `sent_messages`: messages to send through Sender's send_message method
    """
    channel = Channel()
    sender = sender_cls(channel)
    for message in sent_messages:
        sender.send_message(message)
    the_bytes = distort_function(channel.got_bytes)
    received_messages = []
    receiver = receiver_cls(lambda x: received_messages.append(bytes(x)))
    for byte in the_bytes:
        receiver.handle_byte_from_network(byte)
    sent_messages = list(map(bytes, sent_messages))
    received_messages = list(map(bytes, received_messages))
    matches = SequenceMatcher(a=sent_messages, b=received_messages, autojunk=False)
    results = []
    extra_messages = 0
    corrupted_messages = 0
    missing_messages = 0
    missing_in_results = 0
    maximum_results = 10
    for tag, i1, i2, j1, j2 in matches.get_opcodes():
        if i2 < 0:
            i2 = len(sent_messages) + i2
        if j2 < 0:
            j2 = len(received_messages) + j2
        if tag == 'equal':
            pass
        elif tag == 'delete':
            if len(results) < maximum_results:
                results.append(f'missing input {_range(i1, i2)}')
            else:
                missing_in_results += 1
            missing_messages += (i2 - i1)
        elif tag == 'insert':
            if len(results) < maximum_results:
                results.append(f'extra output {_range(j1, j2)}')
            else:
                missing_in_results += 1
            extra_messages += (j2 -j1)
        elif tag == 'replace':
            corrupted_messages += (j2 - j1)
            if len(results) < maximum_results:
                results.append(f'possibly corrupted input {_range(i1, i2)} in output {_range(j1, j2)}')
                actual_count = j2 - j1
                for offset in range(min(3, actual_count)):
                    results.append(f'  input message #{i1 + offset} (as hexadecimal bytes):\n'
                                   f'    {_format_message(sent_messages[i1+offset])}\n'
                                   f'  output message #{j1 + offset} (as hexadecimal bytes):\n'
                                   f'    {_format_message(received_messages[j1+offset])}\n'
                    )
                if actual_count > 3:
                    results.append(f'  + {actual_count - 3} more')
            else:
                missing_in_results += 1
        else:
            raise Exception(f'internal error --- unknown difflib tag {tag}')
    if missing_in_results > 0:
        results.append(f'+ {missing_in_results} more messages, not shown')

    return {
        'raw_bytes_sent': channel.got_bytes, # to enable tests that encode parts of messages in future messages
        'raw_distorted_bytes': the_bytes,
        'extra_messages': extra_messages,
        'corrupted_messages': corrupted_messages,
        'missing_messages': missing_messages,
        'results_text': results,
    }

def identity(x):
    """Function for 'corrupting' messages that does nothing."""
    return x

def get_rng():
    global random_seed
    rng = random.Random(random_seed)
    return rng

def do_corrupt(old_bytes, flip_rate, add_rate, delete_rate, add_count, delete_count, corrupt_limit_portion):
    """
    Implementation of message corruption. Tests use make_corrupt() to generate something taht will call this with
    appropraite arguments.
    """
    assert len(old_bytes) > 0, "sender produced no bytes?"
    new_bytes = bytearray(old_bytes)
    rng = get_rng()
    if corrupt_limit_portion == None:
        corrupt_limit = len(old_bytes)
    else:
        corrupt_limit = ceil(len(old_bytes) * corrupt_limit_portion)
    if len(old_bytes) > 0 and (delete_rate > 0 or delete_count > 0):
        delete_count += ceil(corrupt_limit * delete_rate)
        delete_points = sorted(rng.sample(range(corrupt_limit), delete_count))
        new_bytes = bytearray(len(old_bytes) - len(delete_points))
        out_loc = 0
        in_loc = 0
        for i in delete_points:
            count = i - in_loc
            new_bytes[out_loc:out_loc + count- 1] = old_bytes[in_loc:in_loc + count - 1]
            in_loc += count
            in_loc += 1
            out_loc += count
        new_bytes[out_loc:] = old_bytes[in_loc:]
        old_bytes = new_bytes
        corrupt_limit = min(corrupt_limit, len(old_bytes))
    if len(old_bytes) > 0 and flip_rate > 0:
        new_bytes = bytearray(old_bytes)
        flip_points = sorted(rng.sample(range(len(old_bytes)), ceil(len(old_bytes) * flip_rate)))
        for i in flip_points:
            new_bytes[i] ^= (1 << rng.randrange(8))
        old_bytes = new_bytes
    if len(old_bytes) > 0 and (add_rate > 0 or add_count > 0):
        add_count += ceil(corrupt_limit * add_rate)
        add_points = sorted(rng.sample(range(corrupt_limit), add_count))
        new_bytes = bytearray(len(old_bytes) + len(add_points))
        out_loc = 0
        in_loc = 0
        for i in add_points:
            count = i - in_loc
            new_bytes[out_loc:out_loc + count] = old_bytes[in_loc:in_loc + count]
            in_loc += count
            out_loc += count
            new_bytes[out_loc] = rng.randrange(0, 256)
            out_loc += 1
        new_bytes[out_loc:] = old_bytes[in_loc:]
        old_bytes = new_bytes
    return new_bytes

def make_corrupt(flip_rate=0, add_rate=0, delete_rate=0, add_count=0, delete_count=0, corrupt_limit_portion=None):
    """Generate a function to corrupt a message. Parameters:

    *  flip_rate: portion of bytes in which to flip a bit (at random)
    *  add_rate: portion of bytes for which to add an additional byte (at random)
    *  delete_rate: portion of bytes to delete (at random)
    *  corrupt_limit_portion: portion of bytes to limit corruption to (to test recovery from corrupted bytes)
    """
    result = lambda x: do_corrupt(old_bytes=x, flip_rate=flip_rate,
                                  add_rate=add_rate, delete_rate=delete_rate,
                                  add_count=add_count, delete_count=delete_count,
                                  corrupt_limit_portion=corrupt_limit_portion)
    result.__name__ = 'corrupt (change byte {flip_rate * 100}%, add byte {add_rate * 100}% + {add_count}, delete byte {delete_rate * 100}% + {delete_count})' + ('--- but only first {corrupt_limit_portion * 100}% of data')
    return result

def test_and_report(
        label,
        sender_cls,
        receiver_cls,
        distort_function,
        sent_messages,
        maximum_missing=None,
        maximum_corrupted=0,
        verbose=False,
    ):
    results = run_one(sender_cls, receiver_cls, distort_function, sent_messages)
    print(f"{label}: {results['extra_messages']} extra; {results['corrupted_messages']} corrupted; {results['missing_messages']} missing")
    failed_p = False
    errors = 0
    if results['extra_messages'] > 0:
        print(f"  ERROR --- extra messages")
        errors += 1
    if maximum_missing != None and results['missing_messages'] > maximum_missing:
        print(f"  ERROR --- too many missing messages")
        errors += 1
    if maximum_corrupted != None and results['corrupted_messages'] > maximum_corrupted:
        if maximum_corrupted == 0:
            print(f"  ERROR --- corrupted messages (none expected)")
        else:
            print(f"  ERROR --- more corrupted messages than expected (threshold {maximum_corrupted})")
        errors += 1
    if verbose:
        for item in results['results_text']:
            print(f"  {item}")
    results['errors'] = errors
    return results


def _do_quote_previous_messages(results, previous_test, locations, before, after):
    raw_bytes = results[previous_test]['raw_bytes_sent']
    messages = []
    if before:
        messages += before
    for location in locations:
        messages.append(raw_bytes[location[0]:location[1]])
    if after:
        messages += after
    return messages

def make_messages_using_sent_bytes(previous_test, locations, before=None, after=None):
    return lambda results: _do_quote_previous_messages(results, previous_test=previous_test, locations=locations, before=before, after=after)

TESTS = [
    ('three-message-clean', {
        'distort_function': identity,
        'sent_messages': [b'message 1', b'message 2', b'message 3'],
        'maximum_missing': 0,
        'maximum_corrupted': 0,
    }),
    ('recursive-three-message-clean', {
        'distort_function': identity,
        'sent_messages_generator': make_messages_using_sent_bytes(
            previous_test='three-message-clean',
            locations=[(0, 200), (1, 10), (0, 5), (10, 20), (0, 10), (1, -1)],
            before=[b'before weird messages'],
            after=[b'after weird messages']
        ),
        'maximum_missing': 0,
        'maximum_corrupted': 0,
    }),
    ('with-empty-message-clean', {
        'distort_function': identity,
        'sent_messages': [b'before', b'', b'after'],
        'maximum_missing': 0,
        'maximum_corrupted': 0,
    }),
    ( 'three-message-binary-clean', {
        'distort_function': identity,
        'sent_messages': [
            b'\x00\x01\x02\x03message 1' + bytes(range(256)),
            b'\x0a\x0d\x00\x0d\x0amessage 2' + bytes(range(128, 256)) + bytes(range(0, 128)),
            b'\x9a\x00message 1' + bytes(range(128, 256)) + bytes(range(1, 128, 5)),
        ],
        'maximum_missing': 0,
        'maximum_corrupted': 0,
    }),
    ('three-long-message-clean', {
        'distort_function': identity,
        'sent_messages': [b'message 1 ' + (b'X' * 1000), b'message 2' + (b'Y' * 999), b'message 3' + (b'XY' * 501)],
        'maximum_missing': 0,
        'maximum_corrupted': 0,
    }),
    ('many-message-clean', {
        'distort_function': identity,
        'sent_messages': list(map(lambda x: f'message {x}'.encode('us-ascii'), range(10000))),
        'maximum_missing': 0,
        'maximum_corrupted': 0,
    }),
    ('many-message-clean-varlen', {
        'distort_function': identity,
        'sent_messages': list(map(lambda x: f'message {x} {"Z" * ((x*137)%131)}'.encode('us-ascii'), range(10000))),
        'maximum_missing': 0,
        'maximum_corrupted': 0,
    }),
    ('many-message-corrupt', {
        'distort_function': make_corrupt(flip_rate=0.0005),
        'sent_messages': list(map(lambda x: f'this is message {x}'.encode('us-ascii'), range(10000))),
        # With a .05% of rate of corruption, if messages take 30 bytes to encode, we'd expect
        # each message has around a 2% chance of being corrupted.
        # So we expect around 200 messages to be directly corrupted.
        # We also expect some number of messages to be indirectly corrupted, I guess
        # that that might average around 3 per message, and we then add a factor of 3 above that.
        'maximum_missing': 1200,
        'maximum_corrupted': 1,
    }),
    ('many-message-corrupt2', {
        'distort_function': make_corrupt(add_rate=0.00025, delete_rate=0.00025),
        'sent_messages': list(map(lambda x: f'message {x}'.encode('us-ascii'), range(10000))),
        'maximum_missing': 1200,
        'maximum_corrupted': 1,
    }),
    ('many-message-corrupt-varlen', {
        'distort_function': make_corrupt(flip_rate=0.0005),
        'sent_messages': list(map(lambda x: f'message {x} {"Z" * ((x*137)%131)}'.encode('us-ascii'), range(10000))),
        'maximum_missing': 1200,
        'maximum_corrupted': 1,
    }),
    ('many-message-corrupt-varlen2', {
        'distort_function': make_corrupt(flip_rate=0.00003, add_rate=0.00003, delete_rate=0.00003),
        'sent_messages': list(map(lambda x: f'message {x} {"Z" * ((x*137)%131)}'.encode('us-ascii'), range(10000))),
        'maximum_missing': 1200,
        'maximum_corrupted': 1,
    }),
    ('many-message-corrupt-varlen3', {
        'distort_function': make_corrupt(add_count=10, delete_count=10),
        'sent_messages': list(map(lambda x: f'{struct.pack("H", x)}{bytes([x % 255]) * (1+(x*137)%7)}'.encode('us-ascii'), range(10000))),
        # guess around 20 messages corrupted, and each corrupted message causing 200 mesages to be missed due to
        # desync at most
        'maximum_missing': 4000,
        'maximum_corrupted': 1,
    }),
    ('many-message-corrupt-recover', {
        'distort_function': make_corrupt(flip_rate=0.0001, add_rate=0.0001, delete_rate=0.0001, corrupt_limit_portion=0.1),
        'sent_messages': list(map(lambda x: f'{struct.pack("H", x)}{bytes([x % 255]) * (1+(x*137)%7)}'.encode('us-ascii'), range(10000))),
        # many of first 10% of (1000) messages corrupted, should recover after that
        'maximum_missing': 1200,
        'maximum_corrupted': 1,
    }),
    ('many-message-corrupt-recover2', {
        'distort_function': make_corrupt(flip_rate=0.0001, add_rate=0.0001, delete_rate=0.0001, corrupt_limit_portion=0.01),
        'sent_messages': list(map(lambda x: f'{struct.pack("H", x)}{bytes([x % 255]) * (1+(x*137)%7)}'.encode('us-ascii'), range(10000))),
        # many of first 1% of (100) messages corrupted, should recover after that
        'maximum_missing': 300,
        'maximum_corrupted': 1,
    }),
]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test-module', default='sendrecv',
        help='python module to test (default: sendrecv, meaning sendrecv.py)')
    parser.add_argument('--sender-class', default='MySender',
        help='sender class to test (default: MySender)')
    parser.add_argument('--receiver-class', default='MyReceiver',
        help='receiver class to test (defualt: MyReceiver)')
    parser.add_argument('--random-seed', default=42, type=int,
        help='random seed to use for random parts of tests')
    parser.add_argument('--verbose', action='store_true', default=False,
        help='enable verbose output')
    args = parser.parse_args()
    global random_seed
    random_seed = args.random_seed
    module = importlib.import_module(args.test_module)
    sender_cls = module.__dict__[args.sender_class]
    receiver_cls = module.__dict__[args.receiver_class]

    global TESTS
    failure = False
    results = {}
    for label, test_args in TESTS:
        test_args = copy.copy(test_args)
        if test_args.get('sent_messages_generator'):
            test_args['sent_messages'] = test_args['sent_messages_generator'](results)
            del test_args['sent_messages_generator']
        results[label] = test_and_report(label=label,
            sender_cls=sender_cls, receiver_cls=receiver_cls,
            verbose=args.verbose,
            **test_args)
        if results[label]['errors'] > 0:
            failure = True
            break

    if failure:
        print("*** a test failed. stopped.")
    else:
        print("*** all tests passed.")



    

if __name__ == '__main__':
    main()
