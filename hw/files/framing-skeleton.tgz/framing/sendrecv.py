class NullTerminatedSender:
    def __init__(self, channel):
        self.channel = channel

    def send_message(self, message_bytes):
        self.channel.send_bytes(message_bytes)
        self.channel.send_bytes(b'\0')

class NullTerminatedReceiver:
    def __init__(self, got_message_function):
        self.got_message_function = got_message_function
        self.so_far = b''

    def handle_byte_from_network(self, the_byte):
        if the_byte == 0:
            self.got_message_function(self.so_far)
            self.so_far = b''
        else:
            self.so_far += bytes([the_byte])

class MySender:
    def __init__(self, channel):
        self.channel = channel

    def send_message(self, message_bytes):
        # FIXME: your code here
        pass

class MyReceiver:
    def __init__(self, got_message_function):
        self.got_message_function = got_message_function

    def handle_byte_from_network(self, the_byte):
        # FIXME: your code here instead of this
        self.got_message_function(self.so_far)

