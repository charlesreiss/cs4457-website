import config
from util import Packet, Message

import argparse
import json
import random
import re
import sys
from collections import deque
from dataclasses import dataclass
from heapq import heappush, heappop
from typing import Optional

_simulator = None

def get_simulator():
    global _simulator
    assert _simulator != None
    return _simulator

@dataclass
class Event:
    time: float
    action: callable
    description: str
    index: int = 0
    canceled: bool = False

    def __lt__(self, other) -> bool:
        if self.time == other.time:
            return self.index < other.index
        else:
            return self.time < other.time

class Link:
    def __init__(self, buffer_size, bandwidth, delay, delay_variance, drop, destination, simulation, label):
        self._bandwidth = bandwidth
        self._buffer_size = buffer_size
        self._delay = delay
        self._delay_variance = delay_variance
        self._drop = drop
        self._destination = destination
        self._buffer = deque()
        self._pending_transmit = None
        self._simulation = simulation
        self._label = label
        self._total_dropped = 0

    def get_rng(self):
        return self._simulation.get_rng()

    def _transmit(self, packet):
        if self.get_rng().uniform(0.0, 1.0) > self._drop:
            delay = self._delay
            if self._delay_variance > 0:
                delay += self.get_rng().expovariate(self._delay_variance)
            self._simulation.trace(f'sending {packet} to {self._label} [{delay} transmission time]')
            self._simulation.create_timer(
                delay,
                lambda: self._destination.from_network(packet),
                f'receiving {packet} at {self._label}'
            )
        else:
            self._simulation.trace(f'sending {packet} to {self._label} [randomly dropped]')

    def transmit_next(self):
        if len(self._buffer) > 0:
            self._transmit(self._buffer.popleft())
            self._pending_transmit = self._simulation.create_timer(
                1.0 / self._bandwidth,
                lambda: self.transmit_next(),
                f'dequeue from buffer at {self._label}',
            )
        else:
            self._pending_transmit = None

    def enqueue(self, packet):
        if len(self._buffer) < self._buffer_size:
            self._buffer.append(packet)
            self._simulation.trace(f'buffering {packet} to {self._label} (buffer size {len(self._buffer)})')
        else:
            self._total_dropped += 1
            self._simulation.trace(f'dropping {packet} to {self._label} due to full buffer')
        if self._pending_transmit == None:
            self.transmit_next()

    def json_info(self):
        return {
            'label': self._label,
            'total_dropped': self._total_dropped,
            'buffer_size': self._buffer_size,
            'delay': self._delay,
            'delay_variance': self._delay_variance,
            'drop_rate': self._drop,
        }

class Simulator:
    def __init__(self, args):
        self._args = args
        self._rng = random.Random(42)
        self._event_list = []
        self._next_index = 0
        self._time = 0.0
        self._in_run_event = False
        self._total_sent = 0
        self._total_received = 0
        self.pending_messages = deque()
        self.in_flight_messages = deque()
        self.done = False

    def get_rng(self):
        return self._rng

    def send_messages(self, messages: list[Message]):
        self.pending_messages.extend(messages)
        self.send_pending()

    def send_pending(self) -> None:
        global the_sender
        while len(self.pending_messages) > 0:
            if self.sender.from_application(self.pending_messages[0]):
                message = self.pending_messages.popleft()
                self._total_sent += 1
                self.trace(f'sent message #{self._total_sent} ({message})')
                self.in_flight_messages.append(message)
            else:
               break

    def record_received(self, actual_message: Message) -> None:
        if len(self.in_flight_messages) == 0:
            # FIXME: for diagnosis, detect if duplicate
            raise Exception(f'received excess message {actual_message}')
        expect_message = self.in_flight_messages.popleft()
        self._total_received += 1
        if expect_message != actual_message:
            # FIXME: for diagnosis, detect if out-of-order
            raise Exception(f'received wrong message #{self._total_received}, got {actual_message}, expected {expect_message}')
        self.trace(f'received message #{self._total_received} ({actual_message})')
        self.trace(f'successfully received message #{self._total_received} ({actual_message})')
        if actual_message.is_end:
            self.done = True


    def time(self) -> float:
        return self._time

    def add_event(self, event: Event) -> None:
        event.index = self._next_index
        self._next_index += 1
        heappush(self._event_list, event)

    def _pop_event(self) -> Optional[Event]:
        if len(self._event_list) > 0:
            return heappop(self._event_list)
        else:
            return None

    def trace(self, description):
        if config.TRACE:
            print(f"at time={self._time:9.1f}: {description}")

    def _run_next(self) -> bool:
        assert not self._in_run_event
        event = self._pop_event()
        if event != None:
            self._time = max(self._time, event.time)
            if not event.canceled:
                self._in_run_event = True
                self.trace(f"running {event.description}")
                event.action()
                self._in_run_event = False
            return True
        else:
            return False

    def run(self):
        global _simulator
        assert _simulator == self
        self._links = {
            'receiver': Link(
                bandwidth=self._args.bandwidth_forward,
                buffer_size=self._args.buffer,
                delay=self._args.delay,
                delay_variance=self._args.delay_variance,
                drop=self._args.drop,
                destination=self.receiver,
                simulation=self, 
                label='receiver'
            ),
            'sender': Link(
                bandwidth=self._args.bandwidth_backward,
                buffer_size=self._args.buffer,
                delay=self._args.delay,
                delay_variance=self._args.delay_variance,
                drop=self._args.drop,
                destination=self.sender,
                simulation=self, 
                label='sender'
            ),
        }
        assert get_simulator() == self
        while not self.done and self._run_next():
            pass
        if len(self.in_flight_messages) > 0:
            raise Exception(f'terminated without receiving some messages: {self.in_flight_messages}')

    def _finish_send_back(self, to, destination, packet):
        destination.from_network(packet)
        self._scheduled_by_link[to] -= 1

    def send_packet(self, packet, to=None):
        if to not in self._links:
            raise Exception(f'internal error, invalid packet destination {to}')
        self._links[to].enqueue(packet)
    def create_timer(self, timeout, function, description) -> Event:
        event = Event(
            time = self.time() + timeout,
            action = function,
            description = description
        )
        self.add_event(event)
        return event

def run(args, sender, receiver, messages):
    global _simulator
    _simulator = Simulator(args)
    receiver._simulator = _simulator
    sender._simulator = _simulator
    _simulator.receiver = receiver
    _simulator.sender = sender
    _simulator.add_event(
        Event(
            time=0,
            action=lambda: _simulator.send_messages(messages),
            description='initial data send'
        ),
    )
    _simulator.run()
    if args.json:
        json.dump({
            'messages': _simulator._total_received,
            'mode': config.MODE,
            'initial_window': config.INITIAL_WINDOW,
            'timeout': config.TIMEOUT,
            'time': _simulator.time(),
            'receiver_link': _simulator._links['receiver'].json_info(),
            'sender_link': _simulator._links['sender'].json_info(),
        }, fp=sys.stdout)
        sys.stdout.write('\n')
    else:
        print(f'received {_simulator._total_received} messages; finished after {_simulator.time()} time units')

def _convert_bool(s: str) -> bool:
    if s == 'true' or s == 'True':
        return True
    elif s == 'false' or s == 'False':
        return False
    else:
        raise ValueError

_convert_bool.__name__ = 'bool'

class SetBothBandwidth(argparse.Action):
    def __call__(self, parser, args, values, option_string):
        setattr('bandwidth_forward', values[0])
        setattr('bandwidth_backward', values[0])

if __name__ == '__main__':
    import ends
    parser = argparse.ArgumentParser()
    parser.add_argument('--json', help='enable JSON-format output', default=False, action='store_true')
    config_group = parser.add_argument_group('config.py settings')
    config_items = []
    for item in dir(config):
        if re.match(r'[A-Z]+', item):
            the_type = type(config.__dict__[item])
            normalized_option= item.replace('_', '-').lower()
            if the_type == bool:
                the_type = _convert_bool
            config_group.add_argument(f'--{normalized_option}', f'--{item}',
                action='store',
                dest=item,
                type=the_type,
                default=config.__dict__[item],
                help=f'set config.{item}',
            )
            config_items.append(item)

    input_group = parser.add_argument_group('simulated input settings')
    input_group.add_argument('--input', type=argparse.FileType('rb'), help='input file', metavar='FILE')
    input_group.add_argument('--generate-input', type=int, help='generate input of this number of messages instead of reading file', metavar='COUNT')
    input_group.add_argument('--message-size', default=20)

    sim_group = parser.add_argument_group('simulated link settings')
    sim_group.add_argument('--drop', metavar='DROP-RATE',
        help='simulated random drop rate (in addition to congestion-related drops from bandwidth/buffer limit) (default: 0)', default=0.0, type=float)
    sim_group.add_argument('--delay', help='minimum simulated link delay (defualt: 1 time unit)', default=1.0, type=float,
        metavar='TIME')
    sim_group.add_argument('--delay-variance', help='average extra random delay; total transmission delay will be the delay setting + an exponentially distributed extra delay (default: 0 extra delay)', default=0.0, type=float,
        metavar='TIME')
    sim_group.add_argument('--bandwidth', help='set simulated link bandwidth in both directions',
        type=float, default=None, action=SetBothBandwidth)
    sim_group.add_argument('--bandwidth-forward', help='simulated link bandwidth to receiver in packets per time unit (default: infinite)',
        default=float('inf'), type=float)
    sim_group.add_argument('--bandwidth-backward', help='simulated link bandwidth to sender in packets per time unit (default: infinite)',
        default=float('inf'), type=float)
    sim_group.add_argument('--buffer', help='simulated link buffer size in packets (default: 1 million)',
        default=1000000, type=float)

    args = parser.parse_args()
    for item in config_items:
        config.__dict__[item] = args.__dict__[item]
    messages = []
    if args.input and args.generate_input == None:
        while True:
            current = args.input.read(args.message_size)
            is_end = len(current) < args.message_size
            messages.append(Message(
                data=current,
                is_end=is_end,
            ))
            if is_end:
                break
    elif args.input == None and args.generate_input != None:
        for i in range(args.generate_input):
            messages.append(Message(
                data=f'M{i:#019x}'.encode('utf-8'),
                is_end = (i == args.generate_input - 1)
            ))
    run(args, ends.ReliableSender(), ends.ReliableReceiver(), messages)
