## all the options here can be overriden on the command-line

"""one of 'no-ack', 'one-zero', 'sliding', 'variable-sliding'"""
MODE = 'no-ack'

"""initial window size for 'sliding' and 'variable-sliding' mode"""
INITIAL_WINDOW = 5

"""maximum sequence number for packets for 'sliding' and 'variable-sliding' mode; sequence numbers should be in [0, MAXIMUM_SEQUENCE]"""
MAXIMUM_SEQUENCE = 1000000

"""maximum window size for `variable-sliding` mode."""
MAXIMUM_WINDOW = 100

"""timeout to use for resending packets"""
TIMEOUT = 10

"""types of events to output trace info for.

'all' matches all event, otherwise, name listed much last type passed as first arg to trace() function."""
TRACE = set(['all'])

