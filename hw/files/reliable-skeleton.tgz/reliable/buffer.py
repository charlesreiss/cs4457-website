from collections import deque

class DropTailBuffer:
    def __init__(self, capacity, label):
        self._queue = deque()
        self._capacity = capacity
        self._label = label
        self._drop_count = 0

    def enqueue(self, packet):
        if len(self._queue) < self._capacity:
            self._queue.append(packet)
        else:
            self._drop_count += 1
            trace('link', f'dropping {packet} on {self._label} link due to full buffer')

    def dequeue(self):
        if len(self._queue) == 0:
            return None
        else:
            return self._queue.popleft()

    def __len__(self):
        return len(self._queue)
