import config

import traceback
from dataclasses import dataclass
from typing import Optional

@dataclass
class Packet:
    data: Optional[bytes] = None
    is_end: bool = False
    seq_num: int = 0
    ack_num: Optional[int] = None

@dataclass
class Message:
    data: bytes
    is_end: bool = False

class TimerSupport:
    import simulator
    def create_timer(self, timeout, function, description=None) -> simulator.Event:
        if description == None:
            the_stack = traceback.extract_stack()
            description = f'timer created on {the_stack[-2][0]} line {the_stack[-2][1]} (in {the_stack[-2][2]})'
        return self._simulator.create_timer(timeout, function, description)

    def cancel_timer(self, timer: simulator.Event) -> None:
        timer.canceled = True

    def trace(self, message: Message) -> None:
        self._simulator.trace(message)

class GenericSender(TimerSupport):
    def to_network(self, packet: Packet) -> None:
        self._simulator.send_packet(packet, to='receiver')

    def ready_for_more_from_application(self):
        self._simulator.send_pending()

class GenericReceiver(TimerSupport):
    def to_application(self, message: Message) -> None:
        self._simulator.record_received(message)

    def to_network(self, packet: Packet) -> None:
        self._simulator.send_packet(packet, to='sender')
