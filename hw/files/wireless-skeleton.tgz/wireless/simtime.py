"""
This module contains tools for implementing simulated time, so the emulation
can be run in realtime or accelerated time.

To use this module, one first calls either set_real_time() or set_fake_time(),
choosing whether the simulated time will track real time or not.

In order to properly advance fake time, this module relies on all threads
using sleep() or Queue.get() to wait for events.

After that is set, this module provides:
*  sleep() and time() functions, which are like the time module's functions.
*  a Queue class, which wraps the queue module.
"""

from dataclasses import dataclass, field
import heapq
import queue
import time as _realtime
import threading

_impl = None

"""
Enable using real time.
"""
def set_real_time():
    global _impl
    _impl = RealTime()

"""
Enable using fake time.
"""
def set_fake_time():
    global _impl
    _impl = FakeTime()

def _check_impl():
    global _impl
    if _impl == None:
        raise Exception("Calling simtime function without calling set_real_time() or set_fake_time() first.")

def time():
    global _impl
    _check_impl()
    return _impl.time()

def sleep(s):
    global _impl
    _check_impl()
    return _impl.sleep(s)

def _mark_waiting():
    global _impl
    _check_impl()
    return _impl.mark_waiting()

def _mark_not_waiting():
    global _impl
    _check_impl()
    return _impl.mark_waiting()


class RealTime():
    """trivial implementation for using real-time"""
    def sleep(self, secs):
        _realtime.sleep(secs)

    def time(self):
        return _realtime.time()

    def mark_waiting(self):
        pass

    def mark_done_waiting(self):
        pass

class Queue:
    def __init__(self):
        self.real_queue = queue.Queue()

    def __getattr__(self, name):
        return getattr(self.real_queue, name)

    def get(self, block=True, timeout=None):
        if block:
            try:
                return self.real_queue.get(block=False)
            except queue.Empty:
                _mark_waiting()
                try:
                    result = self.real_queue.get(block, timeout)
                finally:
                    _mark_not_waiting()
                return result

@dataclass(order=True)
class PendingSleep():
    target_time: float
    index: int
    triggered: bool = field(compare=False)
    cv: threading.Condition = field(compare=False)

# how close threads can be before we consider them "tied" for how much they are sleeping
SLEEP_EPSILON = 0.01


class FakeTime():
    def __init__(self):
        self._mutex = threading.Lock()
        self._current_time = 0.0
        self._next_index = 0
        self._pending_heap = []
        self._waiting_threads = set()

    def time(self):
        return self._current_time

    def _dequeue_next(self):
        old_time = self._current_time
        if len(self._pending_heap) > 0:
            next_dequeue = heapq.heappop(self._pending_heap)
            next_dequeue.triggered = True
            self._current_time = next_dequeue.target_time
            next_dequeue.cv.notify()
        max_target_time = self._current_time
        while len(self._pending_heap) > 0 and \
                self._pending_heap[0].target_time <= self._current_time + SLEEP_EPSILON:
            next_dequeue = heapq.heappop(self._pending_heap)
            next_dequeue.triggered = True
            max_target_time = max(max_target_time, self._current_time)
            next_dequeue.cv.notify()
        self._current_time = max_target_time
        #print(f"advanced from {old_time} to {self._current_time}")

    def mark_waiting_locked(self):
        self._waiting_threads.add(threading.get_ident())
        if len(self._waiting_threads) == threading.active_count():
            self._dequeue_next()

    def mark_not_waiting_locked(self):
        self._waiting_threads.remove(threading.get_ident())

    def mark_waiting(self):
        with self._mutex:
            self.mark_waiting_locked()

    def mark_not_waiting(self):
        with self._mutex:
            self.mark_not_waiting_locked()

    def sleep(self, secs):
        with self._mutex:
            sleep_tracker = PendingSleep(
                target_time=self._current_time + secs,
                index = self._next_index,
                triggered = False,
                cv=threading.Condition(self._mutex),
            )
            self._next_index += 1
            heapq.heappush(self._pending_heap, sleep_tracker)
            self.mark_waiting_locked()
            while not sleep_tracker.triggered:
                sleep_tracker.cv.wait()
            self.mark_not_waiting_locked()
